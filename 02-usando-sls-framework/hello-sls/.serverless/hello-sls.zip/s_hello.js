var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'erickworkspace',
applicationName: 'hello-sls',
appUid: '3Hp4MHQBx0XZHlV8pb',
orgUid: 'b41RKJrJQzddckVnhN',
deploymentUid: '67f719bc-7290-4c65-a183-0dc2bf0e5b56',
serviceName: 'hello-sls',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'dev',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'hello-sls-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
