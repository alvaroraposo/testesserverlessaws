const typeDefinition = `
    type Query {
        getHero: String
    }

    type Mutation {
        createHero: String
    }
`
module.exports = typeDefinition