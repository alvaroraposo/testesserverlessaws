module.exports = {
    schema: require('./heroSchema'),
    resolvers: require('./heroResolvers')
}