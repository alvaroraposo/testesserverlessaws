const typeDefinition = `
    type Query {
        getSkill: String
    }

    type Mutation {
        createSkill: String
    }
`
module.exports = typeDefinition