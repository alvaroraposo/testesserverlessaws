module.exports = {
    schema: require('./skillSchema'),
    resolvers: require('./skillResolvers')
}