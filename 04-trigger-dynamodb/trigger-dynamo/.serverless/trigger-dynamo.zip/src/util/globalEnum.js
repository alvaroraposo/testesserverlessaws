const enumParams = {
    ARG_TYPE: {
        BODY: 'body',
        QUERYSTRING: 'queryStringParameters',
        // todos os outros..
    }
}

module.exports = enumParams