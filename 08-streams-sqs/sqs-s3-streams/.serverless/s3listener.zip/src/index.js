module.exports = {
    s3listener: require('./s3.listener'),
    sqslistener: require('./sqs.listener'),
}